
import { Department } from "../types";

export const DEPARTMENT_HANDBOOKS: Record<string, string> = {
  [Department.ECE]: `
MAJOR: ELECTRICAL AND COMPUTER ENGINEERING (ECE)
DEGREE: Bachelor of Science (BS) in Electrical and Computer Engineering (BSECE)
DEPARTMENT OFFICE: 94 Brett Road, Piscataway, NJ 08854
UNDERGRADUATE DIRECTOR: ECE Building-Room 122, Busch Campus
EMAIL: ECEUndergradDirector@soe.rutgers.edu

OVERALL DEGREE REQUIREMENTS:
• Total Credits: 123 credits required for graduation.
• Residency Requirement: Minimum 51 credits must be 14:332:xxx courses.
• Major GPA: Minimum 2.000 required (includes all 14:332:xxx courses and technical electives).
• Cumulative GPA: Minimum 2.000 required.

SHARED CORE CURRICULUM (COMMON TO EE & CE OPTIONS):
• Freshman Foundation: Gen Chem for Engrs (160:159), Intro to Experimentation (160:171), College Writing (355:101), Calculus I & II (640:151/152), Analytical Physics IA & IB (750:123/124), ID3EA I & II (440:101/102), Engineering Mechanics: Statics (440:221).
• Sophomore Core: Principles of EE I & II + Labs (332:221/223, 332:222/224), Digital Logic Design + Lab (332:231/233), Programming Methodology I (332:252), Probability & Random Processes (332:226), Multivariable Calculus (640:251), Differential Equations (640:244), Analytical Physics IIA + Lab (750:227/229).
• Junior/Senior Core: Discrete Mathematics (332:312), Computer Architecture + Lab (332:331/333), Linear Systems & Signals (332:345), Professionalism/Ethics (332:393), Engineering Economics (540:343), Intro to Capstone Design (332:449), Capstone Design in ECE (332:448).

OPTION-SPECIFIC REQUIREMENTS:
1. ELECTRICAL ENGINEERING (EE) OPTION CORE:
    ◦ Digital Signal Processing + Lab (332:346/348).
    ◦ Electronic Devices + Lab (332:361/363).
    ◦ Digital Electronics + Lab (332:366/368).
    ◦ Restricted Electrical Elective (Choose 1): PM2 (332:351), Info/Network Security (332:424), or Comp/Comm Networks (332:423).
    ◦ Electrical Electives: 3 courses required from approved List 3.4.1.
2. COMPUTER ENGINEERING (CE) OPTION CORE:
    ◦ Programming Methodology II (332:351).
    ◦ Software Engineering (332:452).
    ◦ Intro to Computer Systems (332:434).
    ◦ Digital System Design (332:437).
    ◦ Restricted Computer Elective (Choose 1): Electronic Devices (332:361), Digital Signal Processing (332:346), or Princ. Comm. Systems (332:322).
    ◦ Computer Electives: 3 courses required from approved List 3.5.1.

ELECTIVE DISTRIBUTION RULES:
• Technical Electives: 2 courses (6 credits); includes ECE internships, co-ops, or 200+ level SOE courses.
• Science Math Engineering (SME) Elective: 1 course (3-4 credits); any 200+ level course in Science, Math, or Engineering not already required.
• Humanities/Social Science (H/SS): 18 total credits required. Breakdown: Writing (3 cr), Econ (3 cr), 2 lower-level electives, 2 upper-level (200+) electives.
• General Elective: 1 course (3 credits); almost any university course excluding remedial or athletic courses.

KEY PREREQUISITES & PROGRESSION RULES:
• 332:221 (PEE 1): Pre: Calc II and Physics IB.
• 332:222 (PEE 2): Pre: 332:221 and Multivariable Calc.
• 332:312 (Discrete Math): Pre: Multivariable Calc (can be taken as early as Fall Sophomore year).
• 332:345 (Linear Signals): Pre: 332:222/224, DiffEq, and (ID3EA or IntroComput).
• 332:449 (Intro Capstone): Senior Standing required.
• 332:448 (Capstone Design): Pre: 332:449 and 332:345.

PROFESSIONAL EXPERIENCE & RESEARCH:
• Independent Study (332:491/492): Up to 6 credits; counts as electrical/computer or technical electives; GPA must be above probation.
• ECE Internship (332:495): 3 credits; requires 10 weeks/180 hours; counts as technical elective only.
• Co-Op Internship (332:496/497): 3-6 credits; requires 3-6 months full-time; counts as technical elective only.
• Maximum Credits: Combined total for 491, 492, 495, 496, 497 cannot exceed 9 credits.

EQUIVALENCIES FOR CS MINOR/MAJOR:
• 332:252 (PM1) = 01:198:111 (Intro to CS).
• 332:351 (PM2) = 01:198:112 (Data Structures).
• 332:312 (Discrete Math) = 01:198:205 or 01:640:300.
• 332:226 (Probability) = 01:198:206 or 01:640:477.
• Residency Warning: CS courses do NOT count toward the 51-credit ECE residency requirement.
`,

  [Department.MAE]: `
MAJOR: MECHANICAL ENGINEERING (ME)
Department: Department of Mechanical and Aerospace Engineering (MAE)
Office Location: 98 Brett Road, Piscataway, NJ 08854-8058.
Phone: 848-445-2248/3514.
Website: http://mae.rutgers.edu.

DEGREE REQUIREMENTS:
• Accreditation: EAC/ABET Accredited.
• GPA Requirements: Minimum 2.000 cumulative GPA and 2.000 major GPA (all courses designated with "M" prefix).
• Total Credits: Varies between 120–132 depending on specific departmental paths.

REQUIRED CORE CURRICULUM:
• Freshman Year: General Chemistry for Engineers + Lab (160:159/171), Calculus I & II (640:151/152), Analytical Physics IA & IB (750:123/124), College Writing (355:101), Engineering Mechanics: Statics (440:221), Intro to Engineering (440:100), Intro Computers for Engineers (440:127).
• Sophomore Year: Engineering Mechanics: Dynamics (440:222), Multivariable Calculus (640:251), Differential Equations (640:244), Mechanics of Materials (650:291), CAD in MAE (650:388), Mechatronics (650:361), Thermodynamics (650:351), Analytical Physics IIA & IIB + Labs (750:227/228/229/230), Professional Development & Leadership (650:289).
• Junior Year: Engineering Economics (540:343), Mechanical Properties of Materials (635:407), Advanced Calculus for Engineering (640:421), Fluid Mechanics (650:312), Design of Mechanical Components (650:342), Multiphysics Simulations (650:439), MAE Measurements w/Lab (650:350).
• Senior Year: System Dynamics & Controls (650:401), Mech/Aero Engineering Lab I & II (650:431/432), Heat Transfer (650:481), Design & Manufacturing I & II (650:467/468).

CONCENTRATION OPTIONS:
Students may pursue specific concentrations by using their electives for the following:
• Aerospace (AE): Requires 3 Aerospace-specific departmental electives.
• Energy Systems: Requires 3 Energy Systems-specific departmental electives.
• Packaging (PE): Requires 4 Packaging courses as technical electives, including Intro to Packaging (440:301).

ELECTIVE DISTRIBUTION:
• Departmental Electives: Three (3) courses required. Must be 3-credit, 400-level 650:xxx courses not already required.
• Technical Electives: Two (2) courses required. Must be upper-level science, math, or engineering courses. All MAE departmental electives can count as technical electives.
• Humanities/Social Science (H/SS): 18 total credits required, including College Writing and Engineering Economics. At least two courses (6 credits) must be at the 200-level or higher.
• General Elective: One (1) 3-credit course. Most university courses qualify, excluding remedial or athletic courses.

KEY PREREQUISITES:
• 650:291 (Mechanics of Materials): Pre: 440:221 (Statics).
• 650:439 (Multiphysics Simulations): Pre or Co-requisite: 650:312 (Fluid Mechanics).
• 650:467 (Design & Manufacturing I): Pre: 650:312, 650:342, 650:350, and 650:351.
• 650:468 (Design & Manufacturing II): Pre: 650:467.

PROFESSIONAL PROGRAMS:
• Undergraduate Research (650:298-499): Up to 3 credits total counting toward technical electives; requires a poster presentation.
• Internship (650:495): 3 credits; requires 3-month full-time or part-time experience.
• Co-op (650:496/497): 6 credits; requires 6-month full-time experience; counts as two technical electives.
• Credit Limit: Combined total for Research, Internship, and Co-op counting toward technical electives is 6 credits.
`,

  [Department.CEE]: `
MAJOR: ELECTRICAL AND COMPUTER ENGINEERING (ECE) - COMPUTER OPTION
Undergraduate Director: ECE Building-Room 122, Busch Campus.
e-mail: ECEUndergradDirector@soe.rutgers.edu.

DEGREE REQUIREMENTS:
• Total Credits: 123 credits required for graduation.
• Residency Requirement: Minimum 51 credits must be 14:332:xxx courses.
• Major GPA: Minimum 2.000 required (includes all 14:332:xxx courses and technical electives).
• Cumulative GPA: Minimum 2.000 required.

SHARED MAJOR CORE (COMMON TO EE & CE):
• Freshman Foundation: College Writing (355:101), Calculus I & II (640:151/152), Analytical Physics IA & IB (750:123/124), ID3EA 1 & 2 (440:101/102), Statics (440:221), Gen Chem for Engrs (160:159), Intro to Experimentation (160:171).
• Sophomore Core: Principles of EE I & II + Labs (332:221/223, 222/224), Digital Logic Design + Lab (231/233), Programming Methodology I (252), Probability & Random Processes (226), Multivariable Calculus (640:251), Differential Equations (640:244), Analytical Physics IIA + Lab (750:227/229).
• Junior/Senior Shared Core: Computer Architecture + Lab (331/333), Linear Systems & Signals (345), Discrete Mathematics (312), Professionalism/Ethics (393), Engineering Economics (540:343), Intro to Capstone Design (449), Capstone Design in ECE (448).

COMPUTER OPTION SPECIFIC CORE:
• Required Core Courses: Programming Methodology II (332:351), Software Engineering (332:452), Intro to Computer Systems (332:434), Digital System Design (332:437).
• Restricted Computer Elective: Choice of one (1) from: Electronic Devices (332:361), Digital Signal Processing (332:346), or Princ. Communication Systems (332:322).
• Computer Electives: Three (3) courses required from the approved computer elective list (List 3.5.1).

ADDITIONAL ELECTIVE REQUIREMENTS:
• Technical Electives: Two (2) courses (6 credits); includes ECE internships/co-ops (495/496/497) or 200+ level engineering/science courses.
• Science Math Engineering (SME) Elective: One (1) course (3–4 credits); any 200+ level course in Science, Math, or Engineering not already required.
• Humanities/Social Science (H/SS): 18 total credits required, including College Writing (355:101) and Engineering Econ (540:343). Must include two (2) upper-level (200+) electives.
• General Elective: One (1) course (3 credits); almost any university course excluding remedial or athletic courses.

KEY PREREQUISITES:
• 14:332:221 (PEE 1): Pre: Calc II (640:152) and Physics IB (750:124).
• 14:332:252 (PM1): Pre: ID3EA (440:102) or Intro to Computers (440:127).
• 14:332:345 (Linear Signals): Pre: PEE 2 (332:222/224), DiffEq (640:244), and ID3EA (440:102).
• 14:332:351 (PM2): Pre: PM1 (332:252) or Intro CS (198:111).
• 14:332:452 (Software Eng): Pre: PM2 (332:351).
• 14:332:434 (Intro Comp Systems): Pre: Comp Arch (332:331) and PM2 (332:351).
• 14:332:437 (Digital System Design): Pre: Comp Arch (332:331) and PM2 (332:351).
• 14:332:448 (Capstone): Pre: Intro to Capstone (332:449) and Linear Signals (332:345).

PROGRESSION & POLICIES:
• Discrete Mathematics (312): Can be taken as early as the Fall of sophomore year following Multivariable Calculus.
• Capstone Sequence: 332:449 must be taken in the penultimate semester, followed by 332:448 in the final semester.
• Internship/Co-Op Limit: Combined total credits for Independent Study (491/492) and Internship/Co-Op (495/496/497) cannot exceed 9 credits.
• CS Equivalency: PM1/PM2 can be substituted with 198:111/112 for a CS minor, but CS courses do NOT count toward the 51-credit ECE residency requirement.
`,

  [Department.MSE]: `
MAJOR: MATERIALS SCIENCE AND ENGINEERING (MSE)
Undergraduate Program Director: Professor E. K. Akdoğan, Room 114, McLaren Ceramics Building.
e-mail: eka@soe.rutgers.edu.

DEGREE REQUIREMENTS:
• Total Credits: 123–132 credits total; MSE handbook specifically cites 128 credits for graduation.
• GPA Requirement: Minimum 2.000 cumulative GPA and 2.000 major GPA (all courses with "M" prefix).
• Residency Requirement: Not explicitly numbered like ECE, but the School of Engineering requires at least 30 credits at Rutgers and no more than 12 of the last 42 credits outside Rutgers.

REQUIRED MAJOR CORE (M PREFIX):
• Sophomore Year: Intro to MSE (203), Materials Processing (204), Crystal Chemistry & Structure (205), Mat. Thermodynamics (206), Physics of Materials (212), Laboratory I (252).
• Junior Year: Materials Microprocessing (305), Kinetics of Mat’l Processing (307), Characterization of Materials (309), Strength of Materials (314), EOM Properties of Materials (316), Laboratory II (353), Laboratory III (354).
• Senior Year: Senior MSE Lab I & II (401/402) OR MSE Engineering Design I & II (411/412), MSE Seminar (403/404).

GENERAL EDUCATION & FOUNDATION CORE:
• First Year: General Chemistry I & II (159/160), Intro to Experimentation (171), Calculus I & II (151/152), Analytical Physics IA & IB (123/124), ID3EA I & II (101/102), Statics (221), Engineering Orientation (100).
• Advanced Math/Science: Multivariable Calculus (251), Differential Equations (244), Analytical Physics IIA + Lab (227/229), Statistics (Choice of 960:211, 384, 401, or 490).
• Humanities/Economics: College Writing (355:101), Engineering Economics (540:343), and four H/SS electives (at least two at 300+ level).

ELECTIVE DISTRIBUTION:
• Departmental Electives (4 courses): Must take two from "List A" (312 Glass, 360 Ceramics, 361 Polymers, or 362 Metallurgy) and two from "List B" (includes Nanomaterials, Solar Cells, Venture Analysis, etc.).
• Technical Electives (3 courses): Can be selected from departmental electives or approved science/math/engineering lists (e.g., Biochemistry, CS 200+, MAE 200+).
• General Elective (1 course): Most 3-credit university courses.

AREAS OF CONCENTRATION (CERTIFICATE OPTIONS):
Students can earn a certificate by completing at least 3 courses (9 credits) in one area:
1. Biomaterials.
2. Electronic and Optical Materials.
3. Energy Conversion and Storage.
4. Metals.
5. Nanomaterials.
6. Packaging Materials.
7. Polymers.

KEY PREREQUISITES:
• 635:203 (Intro MSE): Pre/Co-req: Chem II (160:160).
• 635:204 (Processing I): Pre: 635:203.
• 635:206 (Mat. Thermo): Pre: Chem II and DiffEq (640:244).
• 635:307 (Kinetics): Pre: 635:205, 206, and DiffEq.
• 635:314 (Strength): Pre: DiffEq, Physics IB (750:124), and 640:144.
• 635:411 (Design I): Pre: 635:204, 305, 306.

PROFESSIONAL PROGRAMS:
• Co-Op Internship (496/497): 6 credits total (Pass/No Credit); replaces one technical/specialization elective and the general elective. Requires junior standing and 2.5 GPA.
• Special Problems (491/492): Individual research projects; requires signed form from advisor and department.
• James J. Slade Scholars: Research program for students with 3.2+ GPA; involves independent thesis and poster presentation.

MSE-SPECIFIC STUDENT ORGANIZATIONS:
• Material Advantage (ACerS/NICE/MRS).
• Keramos: National Professional Ceramic Engineering Fraternity.
• Society of Plastics Engineers.
`,

  [Department.PACK]: `
MAJOR: APPLIED SCIENCE ENGINEERING - PACKAGING ENGINEERING CONCENTRATION (CODE 073A)
Department: Department of Mechanical and Aerospace Engineering (MAE)
Undergraduate Director: Professor Hao Lin
Forms/Resources: https://mae.rutgers.edu/mae-forms

DEGREE REQUIREMENTS:
• Total Credits: 120 credits required for graduation.
• GPA Requirements: Minimum 2.000 cumulative GPA and 2.000 major GPA (all courses designated with "M" prefix).
• Curriculum Structure: Includes a total of 15 specialized packaging courses, four of which are designated as packaging electives.

REQUIRED PACKAGING CORE (M PREFIX):
• Foundational Core: Intro to Packaging Engineering (440:301), CAD for Packaging Engineering (440:302), Packaging Evaluation (440:371), Packaging Lab I & II (440:470, 473), Distribution Packaging (440:471).
• Advanced Core: Packaging Development Processes (440:418), Packaging Manufacturing I & II (440:373, 477), Innovation and Design (440:419).
• Capstone Sequence: Innovation & Design (440:419) in the fall of senior year, followed by Senior Design (440:420) in the spring.

ELECTIVE DISTRIBUTION:
• Packaging Electives (4 courses): Must be selected from approved list, including Sustainable Packaging (378), Safety Packaging (403), Packaging Printing and Design (406), and Packaging Machinery (468).
• Mechanics Elective (1 course): Choice of Strength of Materials (635:314), Mechanical Properties of Materials (635:407), Mechanics of Solids (180:243), or Mechanics of Materials (650:291).
• Statistics Elective (1 course): Choice of Basic Prob & Stats (960:379), Intermediate Statistical Analysis (960:384), or Basic Statistics for Research (960:401).
• Science Elective (1 course): Choice of Thermodynamics (155:208, 635:206, or 650:351), Elementary Organic Chemistry (160:209), Organic Chemistry I (160:307), Polymer Engineering (635:361), or Glass Engineering (635:312).
• Technical Elective (1 course): Can be fulfilled by 200+ level engineering courses, approved science/math courses, or the Packaging Internship/Co-op (up to 3 credits).
• Humanities/Social Science (H/SS): 18 total credits required, including College Writing (355:101) and Engineering Economics (540:343). Students specifically need two H/SS electives, one of which must be at the 300+ level.

KEY PREREQUISITES & FLOW:
• 14:440:301 (Intro Packaging): Pre: Calculus I (640:151).
• 14:440:302 (CAD Packaging): Pre: Calculus II (640:152) and 440:301.
• 14:440:371 (Pkg Evaluation): Pre: 440:301, 440:302, Multivariable Calculus, and Physics IIA.
• 14:440:471 (Distribution Pkg): Pre: 440:371 and Dynamics (440:222).
• 14:440:420 (Senior Design): Pre: 440:419.

PROFESSIONAL PROGRAMS:
• Co-Op Option: 6-month full-time experience; can earn 6 credits toward technical electives (though only 3 are needed for the degree).
• Internship Option: 3-month full-time or 6-month part-time experience; earns 3 credits toward technical electives.
• Eligibility: Requires completion of major courses by the fall of sophomore year and a 2.5 cumulative GPA.
• Undergraduate Research (440:489): Up to 3 credits total counting toward a technical elective; requires a poster presentation at the end of the year.

CERTIFICATE FOR NON-MAJORS:
• Requirement: 12 total credits.
• Courses: Must complete 14:440:301 plus three additional approved packaging courses.
`,

  [Department.BME]: `
MAJOR: BIOMEDICAL ENGINEERING (BME) 
Department Office: 599 Taylor Road, Piscataway, NJ 08854. 
Undergraduate Director: Dr. Kristen Labazzo (Sakala@soe.rutgers.edu). 
Undergraduate Administrator: Ms. Linda L. Johnson (Lindalj@soe.rutgers.edu).

DEGREE REQUIREMENTS:
• Total Credits: 129 credits required for graduation.
• Major GPA: Minimum 2.000 required (all courses with "M" prefix).
• Cumulative GPA: Minimum 2.000 required.
• Residency Requirement: Minimum 30 credits must be earned at Rutgers; no more than 12 of the last 42 credits can be taken outside Rutgers.

REQUIRED MAJOR CORE (M PREFIX):
• Sophomore Year: Intro to BME (125:201), BME System Physiology (125:255).
• Junior Year: BME Transport Phenomena (125:303), BME Numerical Modeling (125:305), Biomechanics (125:308), BME Devices & Systems + Lab (125:309/310), Biomaterials (125:304), Kinetics & Thermodynamics of Biological Systems (125:306), BME Measurements & Analysis Lab (125:315).
• Senior Year: Senior Design I & II (125:401/402), Senior Design Projects I & II (125:421/422).

NON-DEPARTMENTAL CORE:
• Freshman Year: Gen Chem for Engineers I & II + Lab (160:159/160/171), Calculus I & II (640:151/152), Analytical Physics IA & IB (750:123/124), College Writing (355:101), ID3EA (440:101 or 127), Orientation (440:100), Statics (440:221).
• Sophomore Year: Multivariable Calculus (640:251), Differential Equations (640:244), Analytical Physics IIA & IIB + Labs (750:227/228/229/230), Biology I (119:115) + Lab (119:117), Engineering Economics (540:343).

ELECTIVE DISTRIBUTION:
• Departmental Electives: Four (4) courses required (12 credits total).
• Technical Electives: Four (4) courses required (12 credits total). Includes 200+ level engineering, math, or science courses.
• Life Science Elective: One (1) course required (3 credits). Can be replaced by an additional Technical Elective.
• Humanities/Social Science (H/SS): 18 credits total, including College Writing and Engineering Economics. Must include two upper-level (200+) electives.
• General Elective: One (1) course required (3 credits).

TRACKS (AREAS OF INTEREST):
• Biomedical Computing, Imaging & Instrumentation (BCII): Focuses on modeling physiological systems and sensor development.
• Biomechanics and Rehabilitation Engineering (BRE): Focuses on tissue/fluid mechanics, prosthetics, and assistive devices. (CAD 650:388 is strongly recommended).
• Tissue Engineering and Molecular Bioengineering (TEMB): Focuses on biomaterials, molecular medicine, and biochemistry.

KEY PREREQUISITES & PROGRESSION RULES:
• Rule I: Students cannot register for 300-level BME courses until they have passed both 125:201 and 125:255.
• Rule II: To register for Senior Design, students must pass 6 out of 8 junior core courses. Passed courses MUST include 309, 310, and 315.
• Rule III: Co-op students may take 315 or 309/310 as co-requisites in senior year if all other requirements are met.
• Pre-Medical Students: Must take Biology II (119:116) and a full Organic Chemistry sequence (160:307/308/311).

PROFESSIONAL & RESEARCH PROGRAMS:
• Directed Research (125:291/292): For Freshmen/Sophomores (GPA 3.25+). Credits are extra and do not count toward degree requirements.
• Independent Study (125:491/492): For Juniors/Seniors. Max 6 credits; counts as Technical Elective only.
• BME Internship (125:495): 3 credits (Pass/No Credit). Max 2 internships count toward degree as Technical Electives.
• BME Co-op (125:496/497): 6 credits; requires 6 months continuous full-time work. Counts as Technical Electives.
• Research Scholars Academy (RSA): Selective program (3.5 GPA required). Students earn 9 credits over 3 semesters (490, 493, 494) that count toward Technical or Departmental electives.
• Combined Degree Program (BS/MS or BS/MEng): Accelerates degree completion to 5 years. Requires 3.2 GPA; GRE is waived.
• James J. Slade Scholars: Research program for students with 3.2 GPA. Credits (16:125:587/588) count toward Graduate degrees only, not the BS.
`,

  [Department.ISE]: `
MAJOR: INDUSTRIAL AND SYSTEMS ENGINEERING (ISE)
Department: Department of Industrial and Systems Engineering
Handbook Year: 2024-2025
Handbooks/Resources: http://ise.rutgers.edu

DEGREE REQUIREMENTS:
• Total Credits: 129 credits required for graduation.
• Major GPA: Minimum 2.000 required (includes all courses with "M" prefixes, totaling 67 credits).
• Cumulative GPA: Minimum 2.000 required.
• Residency Requirement: Minimum 30 credits must be earned at Rutgers; no more than 12 of the last 42 credits may be taken outside Rutgers.

CORE CURRICULUM SEQUENCE (M = MAJOR COURSE):
• Freshman Foundation: Gen Chem for Engrs + Lab (160:159/171), Calc I & II (640:151/152), Analytical Physics IA & IB (750:123/124), ID3EA I & II (440:101/102), Statics (440:221), College Writing (355:101).
• Sophomore Core: Multivariable Calc (640:251), Diff Eq (640:244), Physics IIA + Lab (750:227/229), Dynamics (M 440:222), Work Design & Ergo + Lab (M 540:201/202), Eng Probability (M 540:210), Eng Economics (540:343), IE Lab (M 540:213), Accounting for Engrs (33:010:310), Sci & Tech Writing (355:302).
• Junior Core: Eng Statistics (M 540:320), Eng Graphics (M 180:215), Principles of EE I (M 332:221), Mech Prop Materials (M 635:407), Prob Models in OR (M 540:338), Automation + Lab (M 540:382/383), Mfg Processes + Lab (M 540:303/304), Deter Models in OR (M 540:311), Simulation Models (M 540:384), Design of Eng Systems I (M 540:399).
• Senior Core: Design of Eng Systems II (M 540:400), Quality Eng + Lab (M 540:433/434), Prod Plan & Control (M 540:453), Energy Sys Model (M 540:487), Fac Layout & MH (M 540:462).

UNDERGRADUATE SPECIALIZATION TRACKS:
Each track requires 12 credits, 9 of which satisfy Dept/Tech elective slots.
1. Energy Systems: Focuses on efficiency, facility management, and renewable technologies. Electives: 220:334, 332:402, 540:488, 635:405.
2. Financial Systems: Focuses on corporate finance, investment analysis, and derivatives. Required: 33:390:300. Electives: 220:423, 540:575, 33:390:380, 33:390:400, 33:390:420.
3. Manufacturing and Production: Focuses on manufacturing materials, process improvement, and logistics. Electives: 540:485, 150:330, 540:520, 650:388, 33:799:301.
4. Quality and Reliability: Focuses on assessing quality performance indicators and system design fundamentals. Electives: 960:490, 960:463, 540:491/492, 540:507, 540:580, 17:610:560.

ELECTIVE DISTRIBUTION RULES:
• Dept/Tech Electives: Must take one (1) course from List A (Design Electives) and two (2) courses from List B. List A courses may substitute for List B, but not vice versa.
• Humanities/Social Science (H/SS): 18 credits total. Required: 355:101 and 540:343. Remaining 12 credits must include two courses at the 200+ level.

KEY PREREQUISITES:
• 540:210 (Prob): Pre: Calc II.
• 540:311 (Deter OR): Pre: Diff Eq.
• 540:338 (Prob OR): Pre: 540:210 AND Diff Eq.
• 540:382 (Automation): Pre: Diff Eq AND Physics IIA.
• 540:399 (Design I): Pre: 540:338 AND 540:382/383.
• 540:400 (Design II): Pre: 540:303/304 AND 540:384 AND 540:399.
• 540:462 (Facilities): Pre: 540:201/202 AND 540:303/304.

PROFESSIONAL EXPERIENCE & RESEARCH:
• Internships (540:496/497): Requires 135 hours. Counts as a List B technical elective.
• Co-Ops: 6-month full-time experience (Summer + one semester). Requires 270 hours. Counts as two List B technical electives.
• Experiential Credit Limit: Maximum 6 credits total from internships/co-ops applied toward the degree.
• James J. Slade Scholars: Requires 3.2+ GPA and a senior research thesis.
• Engineers Made in Germany (EMIG): 6-week summer program offering up to 9 credits (6 technical, 3 H/SS).

ACADEMIC POLICIES:
• Course Substitutions: Department policy strictly prohibits substitutions for ISE courses.
• Course Failures: F grades are computed into both university and major averages; dropped courses are not.
• Academic Dishonesty: Level two violations (copying, forbidden materials) can lead to suspension for one or more terms.
• Student Societies: Alpha Pi Mu (Honor Society), INFORMS, IISE, SME, and Tau Beta Pi.
`,

  // Fallback for other departments
  "GENERAL": `
RUTGERS SCHOOL OF ENGINEERING - GENERAL SOE REQUIREMENTS
- Humanities/Social Science Electives: 4 total required (2 lower, 2 upper).
- General Elective: 1 required.
- Engineering Economics: 14:540:343 required for all majors.
- Capstone: 2-semester sequence in senior year.
`
};

/**
 * COMPREHENSIVE SOE ACADEMIC POLICY REFERENCE
 * This guide provides a high-density reference for universal SOE rules and administrative tips.
 */
export const UNIVERSAL_POLICY_REFERENCE = `
This compiled guide provides a high-density reference of Rutgers School of Engineering (SOE) academic policies, elective requirements, and departmental rules to serve as a comprehensive knowledge base for an academic advising language model.

1. Universal School of Engineering (SOE) Policies
• GPA Requirements: Students must maintain a cumulative GPA of at least 2.000 and a major GPA of at least 2.000. The major GPA is calculated using all courses designated with an "M" prefix in the curriculum.
• Credit Residency: A minimum of 30 credits must be earned at Rutgers. Additionally, no more than 12 of the last 42 credits may be taken outside of Rutgers.
• Course Repetition: A grade of D or F may be "E-credited" (the original grade is removed from GPA calculation but remains on the transcript) by retaking the course at Rutgers. This is allowed for up to 4 courses. D grades must be repeated immediately before moving to subsequent coursework to remain eligible for E-credit.
• Withdrawal Deadlines: Students may withdraw from courses via the web until the 8th week of the term. Between weeks 8 and 12, an Associate Dean’s permission is required.
• Pass/No Credit: Students may take one elective course on a P/NC basis per term, up to a maximum of two during their entire time at SOE. Departmental "M" prefix courses are not eligible.

--------------------------------------------------------------------------------
2. Humanities/Social Science (H/SS) Requirements
All SOE students must complete 18 credits of H/SS coursework:
• Mandatory Courses: 01:355:101 College Writing (3 cr) and 14:540:343 Engineering Economics (3 cr).
• Elective Distribution: Students must choose four additional electives (12 cr).
• Level Requirement: At least 6 credits (two courses) must be at the 200, 300, or 400 level.
• Subject Variety: At least two different subjects must be represented. It is recommended that two courses come from the same subject (one being upper-level) to create a focus area.
• Department-Specific H/SS Rules:
    ◦ CEE: Must take 01:355:302 Scientific and Technical Writing as an H/SS elective.
    ◦ BME & Packaging: One upper-level H/SS elective must be at the 300+ level.
• Approved Subjects: Traditional subjects include Philosophy, Religion, History, Literature, Fine Arts, Sociology, Psychology, Political Science, Anthropology, Economics, and World Languages.
• The "Wireless" Exception: 14:332:301 Wireless Revolution counts as an upper-level H/SS elective for all SOE majors and fulfills ECE residency.
• Language Rule: Elementary language courses are typically not accepted unless a four-semester sequence (2 elementary, 2 intermediate) is completed in a language not taken in high school.
• Exclusions: Routine exercises of personal craft (Marching Band, Choir), research, and independent studies are not acceptable for H/SS credit.

--------------------------------------------------------------------------------
3. Major-Specific Progression & Rules
• ECE (Electrical/Computer): Requires a minimum of 51 credits in 14:332:xxx courses specifically to satisfy the ECE residency requirement.
• BME (Biomedical):
    ◦ Rule I: Students cannot register for 300-level BME courses until they pass 125:201 and 125:255.
    ◦ Rule II: To enter Senior Design, students must pass 6 out of 8 junior core courses, specifically including 309, 310, and 315.
• MAE (Mechanical/Aerospace): Students must register for the year-long Design and Manufacturing sequence (650:467/468) and finalize project groups between May and July of their junior year.
• CEE (Civil/Environmental): The first three years (6 semesters) are identical for all five CEE concentrations (Structural, Geotechnical, Transportation, Environmental, Water Resources).
• ISE (Industrial/Systems): Strictly prohibits substitutions for any ISE-specific courses.

--------------------------------------------------------------------------------
4. Professional, Honors, & Combined Programs
• Co-Op & Internship: Generally requires a 2.5 cumulative GPA and junior/senior standing (or completion of sophomore major courses).
    ◦ MAE/Packaging: Co-op (6 cr) replaces two technical electives; Internship (3 cr) replaces one.
    ◦ BME: Experiential learning credits are limited to 6 credits total (9 with an exception).
• James J. Slade Scholars: A research program for students with a 3.2+ GPA. Requires a senior thesis and a poster presentation.
• BS/Master's Fast-Track: Most departments offer a 5-year program.
    ◦ CEE: Students with a 3.2 GPA may apply by Sept 15th of senior year; GRE is waived.
    ◦ BME: Allows up to 6-18 graduate credits in the senior year at undergraduate tuition rates.

--------------------------------------------------------------------------------
5. Advising Pro-Tips & Administrative Procedures
• Special Permission Numbers (SPNs):
    ◦ MAE: Requested via an online form; decisions usually sent within 72 hours.
    ◦ CEE: Requested via email to the Undergraduate Program Administrator (Linda Szary) with a specific header: "Student Name, RUID, Course ID, SPN Request".
• Discrete Math Timing: ECE students can now take 14:332:312 as early as the fall of sophomore year after taking Multivariable Calculus.
• CS Minor for ECE: A CS minor is easier under the Computer Option because 198:112 replaces PM2 (332:351).
• Double-Counting: ISE and Economics double majors can satisfy requirements for both using the Engineering Probability and Intermediate Statistics sequence.
• Recommended "Easy" H/SS Electives: Peer advice lists Social Psychology, Population & Society, Theater Appreciation, and Music in Film as manageable 200+ level options

--------------------------------------------------------------------------------
This compiled guide provides a high-density reference of Rutgers School of Engineering (SOE) academic policies, elective requirements, and departmental rules to serve as a comprehensive knowledge base for an academic advising language model.
1. Universal School of Engineering (SOE) Policies
• GPA Requirements: Students must maintain a cumulative GPA of at least 2.000 and a major GPA of at least 2.000. The major GPA is calculated using all courses designated with an "M" prefix in the curriculum.
• Credit Residency: A minimum of 30 credits must be earned at Rutgers. Additionally, no more than 12 of the last 42 credits may be taken outside of Rutgers.
• Course Repetition: A grade of D or F may be "E-credited" (the original grade is removed from GPA calculation but remains on the transcript) by retaking the course at Rutgers. This is allowed for up to 4 courses. D grades must be repeated immediately before moving to subsequent coursework to remain eligible for E-credit.
• Withdrawal Deadlines: Students may withdraw from courses via the web until the 8th week of the term. Between weeks 8 and 12, an Associate Dean’s permission is required.
• Pass/No Credit: Students may take one elective course on a P/NC basis per term, up to a maximum of two during their entire time at SOE. Departmental "M" prefix courses are not eligible.

--------------------------------------------------------------------------------
2. Humanities/Social Science (H/SS) Requirements
All SOE students must complete 18 credits of H/SS coursework:
• Mandatory Courses: 01:355:101 College Writing (3 cr) and 14:540:343 Engineering Economics (3 cr).
• Elective Distribution: Students must choose four additional electives (12 cr).
• Level Requirement: At least 6 credits (two courses) must be at the 200, 300, or 400 level.
• Subject Variety: At least two different subjects must be represented. It is recommended that two courses come from the same subject (one being upper-level) to create a focus area.
• Department-Specific H/SS Rules:
    ◦ CEE: Must take 01:355:302 Scientific and Technical Writing as an H/SS elective.
    ◦ BME & Packaging: One upper-level H/SS elective must be at the 300+ level.
• Approved Subjects: Traditional subjects include Philosophy, Religion, History, Literature, Fine Arts, Sociology, Psychology, Political Science, Anthropology, Economics, and World Languages.
• The "Wireless" Exception: 14:332:301 Wireless Revolution counts as an upper-level H/SS elective for all SOE majors and fulfills ECE residency.
• Language Rule: Elementary language courses are typically not accepted unless a four-semester sequence (2 elementary, 2 intermediate) is completed in a language not taken in high school.
• Exclusions: Routine exercises of personal craft (Marching Band, Choir), research, and independent studies are not acceptable for H/SS credit.

--------------------------------------------------------------------------------
3. Major-Specific Progression & Rules
• ECE (Electrical/Computer): Requires a minimum of 51 credits in 14:332:xxx courses specifically to satisfy the ECE residency requirement.
• BME (Biomedical):
    ◦ Rule I: Students cannot register for 300-level BME courses until they pass 125:201 and 125:255.
    ◦ Rule II: To enter Senior Design, students must pass 6 out of 8 junior core courses, specifically including 309, 310, and 315.
• MAE (Mechanical/Aerospace): Students must register for the year-long Design and Manufacturing sequence (650:467/468) and finalize project groups between May and July of their junior year.
• CEE (Civil/Environmental): The first three years (6 semesters) are identical for all five CEE concentrations (Structural, Geotechnical, Transportation, Environmental, Water Resources).
• ISE (Industrial/Systems): Strictly prohibits substitutions for any ISE-specific courses.

--------------------------------------------------------------------------------
4. Professional, Honors, & Combined Programs
• Co-Op & Internship: Generally requires a 2.5 cumulative GPA and junior/senior standing (or completion of sophomore major courses).
    ◦ MAE/Packaging: Co-op (6 cr) replaces two technical electives; Internship (3 cr) replaces one.
    ◦ BME: Experiential learning credits are limited to 6 credits total (9 with an exception).
• James J. Slade Scholars: A research program for students with a 3.2+ GPA. Requires a senior thesis and a poster presentation.
• BS/Master's Fast-Track: Most departments offer a 5-year program.
    ◦ CEE: Students with a 3.2 GPA may apply by Sept 15th of senior year; GRE is waived.
    ◦ BME: Allows up to 6-18 graduate credits in the senior year at undergraduate tuition rates.

--------------------------------------------------------------------------------
5. Advising Pro-Tips & Administrative Procedures
• Special Permission Numbers (SPNs):
    ◦ MAE: Requested via an online form; decisions usually sent within 72 hours.
    ◦ CEE: Requested via email to the Undergraduate Program Administrator (Linda Szary) with a specific header: "Student Name, RUID, Course ID, SPN Request".
• Discrete Math Timing: ECE students can now take 14:332:312 as early as the fall of sophomore year after taking Multivariable Calculus.
• CS Minor for ECE: A CS minor is easier under the Computer Option because 198:112 replaces PM2 (332:351).
• Double-Counting: ISE and Economics double majors can satisfy requirements for both using the Engineering Probability and Intermediate Statistics sequence.
• Recommended "Easy" H/SS Electives: Peer advice lists Social Psychology, Population & Society, Theater Appreciation, and Music in Film as manageable 200+ level options
`;

export const getHandbookForDept = (dept: Department): string => {
  const specific = DEPARTMENT_HANDBOOKS[dept] || DEPARTMENT_HANDBOOKS["GENERAL"];
  return `${specific}\n\n${UNIVERSAL_POLICY_REFERENCE}`;
};

export const HANDBOOK_KNOWLEDGE_BASE = DEPARTMENT_HANDBOOKS[Department.ECE];
