
export const ELECTIVE_CONTENT = {
  "program_info": {
    "institution": "Rutgers School of Engineering",
    "requirement_type": "Humanities/Social Science (H/SS) & Electives",
    "total_h_ss_credits_required": 18
  },
  "core_h_ss_requirements": {
    "mandatory_courses": [
      { "course_id": "14:540:343", "title": "Engineering Economics", "credits": 3 },
      { "course_id": "01:355:101", "title": "College Writing", "credits": 3 }
    ],
    "elective_rules": {
      "total_elective_courses_required": 4,
      "total_elective_credits_required": 12,
      "upper_level_requirement": "At least 2 courses (6 credits) must be at the 200, 300, or 400 level",
      "minimum_credits_per_course": 3
    }
  },
  "course_selection_logic": {
    "acceptable_themes": [
      "Philosophy", "Religion", "History", "Language", "Literature", "Fine Arts", 
      "Sociology", "Psychology", "Political Science", "Anthropology", "Economics", 
      "World Languages", "Communications"
    ],
    "inclusion_criteria": "Courses must be non-technical, instill cultural values, and broaden education",
    "exclusion_criteria": [
      "Routine exercises of personal craft without theory/history (e.g., Marching Band, Choir)",
      "Research and independent studies",
      "Courses with an 'E' credit prefix"
    ]
  },
  "subject_specific_approvals": {
    "01:014": { "subject": "Africana Studies", "exclusions": ["223", "224", "341", "342", "460", "490-498"] },
    "01:070": { "subject": "Anthropology", "exclusions": ["291-294", "334", "335", "349", "354", "355", "358", "359", "390-395", "495-498"] },
    "04:189": { "subject": "Comm and Info", "approved_list": ["101", "120", "121"], "explicit_rejection": ["220"] },
    "01:220": { "subject": "Economics", "exclusions": ["110", "212", "322", "326", "386", "397-399", "401-410", "421", "490-496"] },
    "01:355": { "subject": "English Writing", "approved_list": ["201", "203", "301", "302", "303", "315", "352", "375", "402", "410", "425"] },
    "01:790": { "subject": "Political Science", "exclusions": ["250-253", "300", "391-400", "481-498"] },
    "01:830": { "subject": "Psychology", "exclusions": ["200", "210", "323", "395-398", "411", "413", "490-498"] }
  },
  "prohibited_general_electives": [
    "01:160:110-140 (Remedial Chem)",
    "01:198:107, 110, 170 (Remedial CS)",
    "01:355:096-099, 155, 156 (Remedial Writing)",
    "01:640:011-115 (Remedial Math)"
  ]
};
