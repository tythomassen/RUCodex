
import React, { useState, useEffect, useMemo } from 'react';
import { Department, SystemStatus, KnowledgeSource } from './types';
import ChatInterface from './components/ChatInterface';
import AcademicPlanner from './components/AcademicPlanner';
import { runSystemDiagnostic } from './services/geminiService';
import { getHandbookForDept } from './constants/handbookContent';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'planner'>('chat');
  const [department, setDepartment] = useState<Department>(Department.ECE);
  const [userLibrary, setUserLibrary] = useState<KnowledgeSource[]>([]);
  const [status, setStatus] = useState<SystemStatus>({ apiReachability: 'offline', lastDiagnostic: null });

  // Create a dynamic "Core Handbook" source that updates when the department changes
  const coreHandbookSource = useMemo(() => {
    const handbookText = getHandbookForDept(department);
    const blob = new Blob([handbookText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    return {
      id: `core-handbook-${department.toLowerCase().replace(/\s+/g, '-')}`,
      fileName: `${department} Official Handbook`,
      fileType: 'pdf' as const, 
      department: department,
      summary: `Primary academic rules and prerequisites for the ${department} department.`,
      rawExtractedText: handbookText,
      fileUrl: url,
      timestamp: Date.now()
    };
  }, [department]);

  // Combined library: Current Dept's Core Handbook + User Uploads
  const fullLibrary = useMemo(() => {
    return [coreHandbookSource, ...userLibrary];
  }, [coreHandbookSource, userLibrary]);

  useEffect(() => {
    const checkPulse = async () => {
      const diag: any = await runSystemDiagnostic();
      setStatus({
        apiReachability: diag.apiStatus === 'success' ? 'online' : 'offline', // Quota exceeded will also be treated as 'offline' for the dot indicator
        lastDiagnostic: new Date()
      });
    };
    checkPulse();
    const interval = setInterval(checkPulse, 120000);
    return () => clearInterval(interval);
  }, []);

  const addToLibrary = (source: KnowledgeSource) => {
    setUserLibrary(prev => [...prev, source]);
  };

  const removeFromLibrary = (id: string) => {
    // Prevent removal of core system handbooks
    if (id.startsWith('core-handbook-')) return;
    setUserLibrary(prev => prev.filter(s => s.id !== id));
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fdfdfd]">
      <header className="bg-black text-white shadow-md border-b-4 border-[#cc0033] sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center space-x-4">
            <div className="bg-[#cc0033] p-1.5 rounded-lg text-white font-black text-xl italic tracking-tighter">RU</div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight">RUCodex <span className="text-[10px] font-black opacity-30 italic">NOTEBOOK</span></h1>
                <div 
                  title={`Intelligence Status: ${status.apiReachability}`}
                  className={`w-2 h-2 rounded-full animate-pulse ${
                    status.apiReachability === 'online' ? 'bg-green-500' : 'bg-red-500'
                  }`}
                ></div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-[9px] text-gray-500 font-black uppercase tracking-widest">Advising Domain:</span>
                <select 
                  value={department}
                  onChange={(e) => setDepartment(e.target.value as Department)}
                  className="bg-transparent text-[#cc0033] text-[10px] font-black border-none p-0 focus:ring-0 cursor-pointer hover:underline uppercase"
                >
                  {Object.values(Department).map(d => (
                    <option key={d} value={d} className="bg-gray-900 text-white">{d}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          <nav className="flex space-x-1 bg-gray-900 rounded-full p-1 border border-gray-800">
            <button
              onClick={() => setActiveTab('chat')}
              className={`px-8 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === 'chat' ? 'bg-[#cc0033] text-white shadow-lg' : 'text-gray-500 hover:text-white'
              }`}
            >
              Library & Intelligence
            </button>
            <button
              onClick={() => setActiveTab('planner')}
              className={`px-8 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === 'planner' ? 'bg-[#cc0033] text-white shadow-lg' : 'text-gray-500 hover:text-white'
              }`}
            >
              Sequence Builder
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-[1600px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex flex-col">
        <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 flex overflow-hidden">
            {activeTab === 'chat' ? (
              <ChatInterface 
                dept={department} 
                library={fullLibrary} 
                onAddToLibrary={addToLibrary} 
                onRemoveFromLibrary={removeFromLibrary}
              />
            ) : (
              <AcademicPlanner 
                currentDept={department} 
                library={fullLibrary} 
              />
            )}
          </div>
        </div>
      </main>

      <footer className="bg-gray-900 text-gray-400 py-6 border-t-4 border-[#cc0033]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-left">
            <p className="text-[9px] opacity-30 font-bold tracking-[0.3em] uppercase">NotebookLM Architecture | Rutgers University School of Engineering</p>
          </div>
          <div className="flex space-x-6 text-[10px] font-black uppercase tracking-widest">
            <a href="https://soe.rutgers.edu" target="_blank" className="hover:text-white transition-colors">SOE Main</a>
            <a href="https://catalogs.rutgers.edu" target="_blank" className="hover:text-white transition-colors">SOE Catalog</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;