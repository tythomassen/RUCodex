
export enum Department {
  ECE = 'Electrical & Computer Engineering',
  MAE = 'Mechanical & Aerospace Engineering',
  CEE = 'Civil & Environmental Engineering',
  MSE = 'Materials Science & Engineering',
  PACK = 'Packaging Engineering',
  CBE = 'Chemical & Biochemical Engineering',
  BME = 'Biomedical Engineering',
  ISE = 'Industrial & Systems Engineering'
}

export enum MajorOption {
  GENERAL = 'General/Standard',
  EE = 'Electrical Engineering',
  CE = 'Computer Engineering',
  AERO = 'Aerospace Engineering',
  MECH = 'Mechanical Engineering'
}

export interface Course {
  code: string;
  name: string;
  credits: number;
  prerequisites?: string[];
  coRequisites?: string[];
  term?: 'Fall' | 'Spring' | 'Both';
  status?: 'completed' | 'in-progress' | 'planned';
  grade?: string;
  options?: Course[]; // For elective slots with dropdowns
}

export interface SemesterPlan {
  semesterName: string;
  courses: Course[];
  totalCredits: number;
}

export interface ValidationAlert {
  type: 'PREREQUISITE_MISSING' | 'COREQUISITE_MISSING' | 'SEQUENCE_ERROR' | 'ADVISORY';
  courseCode: string;
  message: string;
  severity: 'high' | 'medium' | 'low';
}

export interface AcademicPlan {
  department: Department;
  majorOption: string;
  years: number;
  semesters: SemesterPlan[];
  rationale: string;
  sources: string[];
  validationAlerts: ValidationAlert[];
}

export interface KnowledgeSource {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'json';
  department: Department;
  summary: string;
  rawExtractedText: string;
  fileUrl: string; // Blob URL for downloading
  timestamp: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  sources?: Array<{ title: string; uri: string }>;
  citedSources?: string[]; // IDs of KnowledgeSources found in text
  diagnostic?: {
    apiStatus: 'success' | 'blocked' | 'error' | 'quota_exceeded'; // Added 'quota_exceeded'
    latency: number;
    endpoint: string;
  };
}

export interface SystemStatus {
  apiReachability: 'online' | 'cors_blocked' | 'offline' | 'quota_exceeded'; // Added 'quota_exceeded'
  lastDiagnostic: Date | null;
}