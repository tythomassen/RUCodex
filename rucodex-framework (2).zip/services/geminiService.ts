import { GoogleGenAI, Type } from "@google/genai";
import { Department, AcademicPlan, KnowledgeSource, ChatMessage } from "../types";
import { REQUIREMENTS_CONTENT } from "../constants/reqContent";
import { ELECTIVE_CONTENT } from "../constants/electiveContent";

const getDeptSearchPrefix = (dept: Department): string => {
  const mapping: Record<string, string> = {
    [Department.ECE]: 'ece',
    [Department.MAE]: 'mae',
    [Department.CEE]: 'cee',
    [Department.MSE]: 'mse',
    [Department.PACK]: 'mae', 
    [Department.CBE]: 'cbe',
    [Department.BME]: 'bme',
    [Department.ISE]: 'ise'
  };
  return mapping[dept] || 'soe';
};

const getRUCodexSystemInstruction = (dept: Department, sources: KnowledgeSource[]) => {
  const sourceContext = sources.map(s => `[SOURCE_ID: ${s.id}] [FILENAME: ${s.fileName}] [DEPT: ${s.department}]\n${s.rawExtractedText}`).join('\n\n---\n\n');
  const deptPrefix = getDeptSearchPrefix(dept);

  const officialRequirements = JSON.stringify(REQUIREMENTS_CONTENT, null, 2);
  const electiveGuidelines = JSON.stringify(ELECTIVE_CONTENT, null, 2);

  return `
You are RUCodex, a world-class AI Academic Advisor for Rutgers University.

CRITICAL KNOWLEDGE HUB (Ground Truth):
1. OFFICIAL CURRICULUM REQUIREMENTS (reqContent):
${officialRequirements}

2. ELECTIVE GUIDELINES (H/SS & General Education Rules):
${electiveGuidelines}

3. USER UPLOADED LIBRARY:
${sourceContext}

ADVISING PROTOCOL:
- When a user asks about required classes for a degree, look FIRST at the "OFFICIAL CURRICULUM REQUIREMENTS" section.
- For H/SS or elective eligibility, cross-reference the "ELECTIVE GUIDELINES" (specifically subject approvals and exclusions).
- Cite your sources. Use "[REQ_CONTENT]" for degree requirements and "[ELECTIVE_DB]" for H/SS advice.
- Always prioritize information from "OFFICIAL CURRICULUM REQUIREMENTS" and "ELECTIVE GUIDELINES" over "USER UPLOADED LIBRARY" if there are direct contradictions. If information is only present in a user-uploaded source, use that.
- If info is missing, search ${deptPrefix}.rutgers.edu or soe.rutgers.edu using your tools.
- Never recommend "prohibited_general_electives" for degree credit.
`;
};

export async function askAdvisor(
  question: string, 
  history: { role: 'user' | 'assistant', content: string }[],
  dept: Department,
  library: KnowledgeSource[]
): Promise<{
  text: string;
  sources: Array<{ title: string; uri: string }>;
  diagnostic: ChatMessage['diagnostic'];
}> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";

  const contents = [
    ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.content }] })),
    { role: 'user', parts: [{ text: `[Active Dept: ${dept}] ${question}` }] }
  ];

  try {
    const response = await ai.models.generateContent({
      model,
      contents: contents as any,
      config: {
        systemInstruction: getRUCodexSystemInstruction(dept, library),
        tools: [{ googleSearch: {} }],
        temperature: 0.2, // Lower temperature for more factual responses
        topP: 0.9,
        topK: 40,
      },
    });

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((c: any) => ({
      title: c.web?.title || 'Rutgers University Official Source',
      uri: c.web?.uri || '#'
    })) || [];

    return { 
      text: response.text || "I apologize, the academic intelligence synthesis pass failed.", 
      sources,
      diagnostic: {
        apiStatus: 'success',
        latency: 0, // Placeholder, actual latency would require measurement
        endpoint: 'Notebook Intelligence Engine'
      }
    };
  } catch (error: any) {
    console.error("Error in askAdvisor:", error);
    if (error.message && error.message.toLowerCase().includes('quota')) {
      return {
        text: "It seems I've hit a quota limit. Please check your Google Cloud billing or try again later. For more information, visit ai.google.dev/gemini-api/docs/billing.",
        sources: [],
        diagnostic: {
          apiStatus: 'quota_exceeded',
          latency: 0,
          endpoint: 'Notebook Intelligence Engine'
        }
      };
    }
    return { 
      text: "INTELLIGENCE_ERR: Pass failed. There was an issue connecting to the academic intelligence engine.", 
      sources: [],
      diagnostic: {
        apiStatus: 'error',
        latency: 0,
        endpoint: 'Notebook Intelligence Engine'
      }
    };
  }
}

export async function ingestKnowledgeFile(file: File, dept: Department): Promise<KnowledgeSource> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = 'gemini-3-flash-preview';
  
  let rawExtractedText = "";
  let summary = "";

  const fileUrl = URL.createObjectURL(file);

  try {
    if (file.type === 'application/pdf') {
      const base64Data = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
      });

      const response = await ai.models.generateContent({
        model,
        contents: [{
          parts: [
            { inlineData: { mimeType: file.type, data: base64Data } },
            { text: "Extract all academic rules, course codes, and requirements. Then provide a 1-sentence summary of this document." }
          ]
        }],
        config: {
          temperature: 0.2,
          topP: 0.9,
          topK: 40,
        },
      });
      rawExtractedText = response.text || "";
      summary = rawExtractedText.split('\n')[0].substring(0, 150) + "...";
    } else {
      const text = await file.text();
      const response = await ai.models.generateContent({
        model,
        contents: [{
          parts: [
            { text: `Synthesize this Rutgers JSON data and provide a 1-sentence summary of the courses/sections included.\n\nDATA:\n${text}` }
          ]
        }],
        config: {
          temperature: 0.2,
          topP: 0.9,
          topK: 40,
        },
      });
      rawExtractedText = text;
      summary = response.text || "Live Rutgers Course/Section Data";
    }
  } catch (error: any) {
    console.error("Error in ingestKnowledgeFile:", error);
    if (error.message && error.message.toLowerCase().includes('quota')) {
      throw new Error("Failed to process file: Quota limit exceeded for API. Please check your Google Cloud billing.");
    }
    throw new Error("Failed to process file: An API error occurred during ingestion.");
  }


  return {
    id: Math.random().toString(36).substring(7),
    fileName: file.name,
    fileType: file.name.endsWith('.json') ? 'json' : 'pdf',
    department: dept,
    summary,
    rawExtractedText,
    fileUrl,
    timestamp: Date.now()
  };
}

export async function runSystemDiagnostic() {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ parts: [{ text: "ping" }] }],
      config: {
          temperature: 0, // Minimal creativity for a diagnostic ping
          topP: 1,
          topK: 1,
      },
    });
    return { apiStatus: 'success' };
  } catch (e: any) {
    console.error("Error in runSystemDiagnostic:", e);
    if (e.message && e.message.toLowerCase().includes('quota')) {
        return { apiStatus: 'quota_exceeded' };
    }
    return { apiStatus: 'error' };
  }
}

export async function generatePlan(
  dept: Department,
  option: string, 
  completedCourses: string[], 
  years: number,
  preferences: string,
  library: KnowledgeSource[],
  dnText: string 
): Promise<AcademicPlan> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-pro-preview";
  
  const prompt = `
    TASK: Generate a full ${years}-year academic sequence for ${dept} (${option}).
    
    INPUT DATA:
    - DEGREE NAVIGATOR DUMP: """${dnText}"""
    - MANUAL COMPLETED LIST: ${completedCourses.join(', ')}
    - USER PREFERENCES: ${preferences}

    PLANNING RULES:
    1. Parse DN dump for completed/in-progress courses.
    2. Cross-reference OFFICIAL CURRICULUM REQUIREMENTS for sequence.
    3. Use ELECTIVE GUIDELINES to populate valid options for H/SS slots.
    4. Provide valid 'options' (array of {code, name, credits}) for elective slots.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        systemInstruction: getRUCodexSystemInstruction(dept, library),
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 8000 },
        responseMimeType: "application/json",
        temperature: 0.2, // Lower temperature for more factual and consistent plan generation
        topP: 0.9,
        topK: 40,
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            department: { type: Type.STRING },
            majorOption: { type: Type.STRING },
            years: { type: Type.NUMBER },
            semesters: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  semesterName: { type: Type.STRING },
                  totalCredits: { type: Type.NUMBER },
                  courses: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: { 
                        code: { type: Type.STRING }, 
                        name: { type: Type.STRING }, 
                        credits: { type: Type.NUMBER },
                        status: { type: Type.STRING },
                        grade: { type: Type.STRING },
                        options: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            properties: { code: { type: Type.STRING }, name: { type: Type.STRING }, credits: { type: Type.NUMBER } }
                          }
                        }
                      },
                      required: ["code", "name", "credits", "status"]
                    }
                  }
                },
                required: ["semesterName", "totalCredits", "courses"]
              }
            },
            validationAlerts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING },
                  courseCode: { type: Type.STRING },
                  message: { type: Type.STRING },
                  severity: { type: Type.STRING }
                },
                required: ["type", "courseCode", "message", "severity"]
              }
            },
            rationale: { type: Type.STRING },
            sources: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["department", "majorOption", "years", "semesters", "validationAlerts", "rationale", "sources"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    console.error("Error in generatePlan:", error);
    if (error.message && error.message.toLowerCase().includes('quota')) {
      throw new Error("Failed to generate plan: Quota limit exceeded for API. Please check your Google Cloud billing. For more information, visit ai.google.dev/gemini-api/docs/billing.");
    }
    throw new Error("Failed to generate plan: An API error occurred during plan synthesis.");
  }
}