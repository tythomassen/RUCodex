
import React, { useState, useRef, useEffect } from 'react';
import { askAdvisor, ingestKnowledgeFile } from '../services/geminiService';
import { ChatMessage, Department, KnowledgeSource } from '../types';

interface ChatInterfaceProps {
  dept: Department;
  library: KnowledgeSource[];
  onAddToLibrary: (source: KnowledgeSource) => void;
  onRemoveFromLibrary: (id: string) => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ dept, library, onAddToLibrary, onRemoveFromLibrary }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: `RUCodex Notebook Active. I am grounded in your ${library.length} active sources, including the SOE Undergraduate Handbook. Ask me anything about sequences, prerequisites, or policies.` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isIndexing, setIsIndexing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getAbbreviatedLink = (uri: string) => {
    try {
      const url = new URL(uri);
      return url.hostname.replace('www.', '');
    } catch {
      return 'Source';
    }
  };

  const getHandbookAbbreviation = (d: Department) => {
    const mapping: Record<string, string> = {
      [Department.ECE]: 'ECE',
      [Department.MAE]: 'MAE',
      [Department.CEE]: 'CEE',
      [Department.MSE]: 'MSE',
      [Department.PACK]: 'PACK',
      [Department.CBE]: 'CBE',
      [Department.BME]: 'BME',
      [Department.ISE]: 'ISE'
    };
    return `${mapping[d] || 'SOE'} HB`;
  };

  const processFile = async (file: File) => {
    setIsIndexing(true);
    try {
      const source = await ingestKnowledgeFile(file, dept);
      onAddToLibrary(source);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `SOURCE ADDED: "${file.name}" is now part of my active context.` 
      }]);
    } catch (error: any) {
      const errorMessage = error.message || "Error processing file.";
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `FILE INGESTION FAILED: ${errorMessage}` 
      }]);
    } finally {
      setIsIndexing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const { text, sources, diagnostic } = await askAdvisor(userMsg, messages, dept, library);
      
      // Basic check to mark internal handbook as cited if its content is used or mentioned
      // This is still a heuristic, a more robust solution would be needed for precise citation from model output.
      const citedIds = library
        .filter(s => text.toLowerCase().includes(s.fileName.toLowerCase()) || text.includes(s.id))
        .map(s => s.id);

      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: text, 
        sources,
        citedSources: citedIds, // Use the more refined citedIds
        diagnostic // Pass diagnostic information
      }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: "INTELLIGENCE_ERR: Pass failed. Check API key or connection." }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Group user uploads by department, and separate the core handbook
  const coreSource = library.find(s => s.id.startsWith('core-handbook-'));
  const userLibrary = library.filter(s => !s.id.startsWith('core-handbook-'));

  const groupedUserSources = Object.values(Department).reduce((acc, d) => {
    const deptSources = userLibrary.filter(s => s.department === d);
    if (deptSources.length > 0) acc[d] = deptSources;
    return acc;
  }, {} as Record<string, KnowledgeSource[]>);

  return (
    <div 
      className="flex-1 flex flex-col bg-[#fdfdfd] relative"
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
    >
      {/* Drag Overlay */}
      {isDragging && (
        <div className="absolute inset-0 z-50 bg-[#cc0033]/90 backdrop-blur-sm flex flex-col items-center justify-center border-8 border-dashed border-white m-4 rounded-3xl animate-in fade-in duration-200">
          <h2 className="text-white text-3xl font-black italic tracking-tighter uppercase">Drop to Ingest Context</h2>
        </div>
      )}

      {/* Header Bar */}
      <div className="bg-white border-b border-gray-100 px-8 py-3 flex items-center justify-between shadow-sm z-30">
        <div className="flex items-center space-x-3">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-[10px] font-black text-gray-900 uppercase tracking-[0.2em] italic">Validated Academic Advisor</span>
        </div>

        <div className="flex items-center space-x-4 relative" ref={menuRef}>
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isIndexing}
            className={`text-[10px] font-black uppercase transition-all px-4 py-2 rounded-lg border shadow-sm ${
              isIndexing ? 'bg-gray-50 text-gray-300 border-gray-100' : 'bg-black text-white border-black hover:bg-[#cc0033] hover:border-[#cc0033]'
            }`}
          >
            {isIndexing ? "Analyzing..." : "+ Upload Context"}
          </button>

          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className={`flex items-center space-x-2 text-[10px] font-black uppercase transition-colors px-3 py-2 rounded-lg ${
              isMenuOpen ? 'bg-gray-100 text-black' : 'text-gray-400 hover:text-black'
            }`}
          >
            <span>Knowledge Hub ({library.length})</span>
            <svg className={`w-3 h-3 transition-transform ${isMenuOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 9l-7 7-7-7" /></svg>
          </button>

          {/* Library Dropdown Menu */}
          {isMenuOpen && (
            <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 py-4 max-h-[70vh] overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-200 z-50">
              {/* Core Source Section */}
              <div className="px-6 pb-2 border-b border-gray-50 mb-3">
                <h3 className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Core Reference</h3>
              </div>
              {coreSource && (
                <div className="px-6 py-2 hover:bg-red-50/50 flex items-center justify-between transition-colors border-l-4 border-[#cc0033]">
                  <div className="flex-1 truncate mr-4">
                    <p className="text-[11px] font-black text-gray-900 truncate">{coreSource.fileName}</p>
                    <p className="text-[8px] text-[#cc0033] uppercase font-black">SYSTEM DEFAULT</p>
                  </div>
                  <a 
                    href={coreSource.fileUrl} 
                    download="SOE_Handbook_Rules.txt"
                    className="text-[#cc0033] hover:scale-110 transition-all"
                    title="Download Core Rules"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                  </a>
                </div>
              )}

              {/* User Uploads Section */}
              <div className="px-6 pb-2 border-b border-gray-50 mb-3 mt-6">
                <h3 className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Your Uploads</h3>
              </div>
              
              {userLibrary.length === 0 ? (
                <div className="px-6 py-4 text-center opacity-20">
                  <p className="text-[9px] font-black uppercase tracking-widest italic">No custom files added</p>
                </div>
              ) : (
                Object.entries(groupedUserSources).map(([groupDept, sources]) => (
                  <div key={groupDept} className="mb-4">
                    <div className="px-6 py-1">
                      <h4 className="text-[8px] font-black text-gray-400 uppercase tracking-widest">{groupDept}</h4>
                    </div>
                    {sources.map(source => (
                      <div key={source.id} className="group px-6 py-2 hover:bg-gray-50 flex items-center justify-between transition-colors">
                        <div className="flex-1 truncate mr-4">
                          <p className="text-[11px] font-bold text-gray-800 truncate">{source.fileName}</p>
                          <p className="text-[8px] text-gray-400 uppercase font-black">{source.fileType}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <a 
                            href={source.fileUrl} 
                            download={source.fileName}
                            className="text-gray-300 hover:text-[#cc0033] transition-all"
                            title="Download"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                          </a>
                          <button onClick={() => onRemoveFromLibrary(source.id)} className="text-gray-300 hover:text-red-500 transition-all">
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-12 space-y-12 scroll-smooth bg-[#fafafa]">
        {messages.map((msg, idx) => {
          // Check for quota_exceeded diagnostic status
          const isQuotaExceeded = msg.diagnostic?.apiStatus === 'quota_exceeded';
          
          return (
            <div key={idx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`max-w-[85%] rounded-[2.5rem] px-10 py-6 shadow-sm relative ${
                msg.role === 'user' 
                  ? 'bg-black text-white font-semibold' 
                  : 'bg-white text-gray-800 border border-gray-200'
              } ${isQuotaExceeded ? 'bg-red-50 border-red-200 text-red-700' : ''}`}>
                <div className="text-[15px] leading-relaxed whitespace-pre-wrap font-medium">
                  {isQuotaExceeded ? (
                    <>
                      <p className="font-bold">API QUOTA EXCEEDED:</p>
                      <p>{msg.content}</p>
                      <p className="mt-2 text-sm">
                        Please check your Google Cloud project's billing settings. 
                        For more information, visit <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-[#cc0033] underline hover:text-red-800">ai.google.dev/gemini-api/docs/billing</a>.
                      </p>
                    </>
                  ) : (
                    msg.content
                  )}
                </div>
              </div>
              
              {/* Citations / Sources underneath */}
              {msg.role === 'assistant' && !isQuotaExceeded && ( // Don't show sources for quota errors
                <div className="mt-4 flex flex-wrap gap-2 px-6">
                  {/* Internal Library Sources (Handbooks/Files) */}
                  {msg.citedSources?.map(sid => {
                    const src = library.find(l => l.id === sid);
                    if (!src) return null;
                    const isHandbook = src.id.startsWith('core-handbook-');
                    return (
                      <div key={sid} className="bg-gray-100 text-gray-600 px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-tight border border-gray-200 flex items-center gap-1.5 shadow-sm">
                        <svg className="w-2.5 h-2.5 opacity-50" fill="currentColor" viewBox="0 0 20 20"><path d="M9 4.804A7.994 7.994 0 005.495 4c-1.258 0-2.453.29-3.515.804v11.986C2.98 16.29 4.175 16 5.432 16c1.257 0 2.452.29 3.568.804A7.997 7.997 0 0112.568 16c1.257 0 2.452.29 3.568.804V4.804A7.994 7.994 0 0012.505 4c-1.258 0-2.453.29-3.515.804z" /></svg>
                        {isHandbook ? getHandbookAbbreviation(src.department) : src.fileName}
                      </div>
                    );
                  })}

                  {/* Web Search Sources */}
                  {msg.sources?.map((src, si) => (
                    <a 
                      key={`web-${si}`} 
                      href={src.uri} 
                      target="_blank" 
                      className="flex items-center gap-2 bg-white border border-gray-200 text-gray-800 px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-tight hover:border-[#cc0033] hover:text-[#cc0033] transition-all shadow-sm group hover:bg-red-50"
                    >
                      <svg className="w-2.5 h-2.5 text-[#cc0033]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                      {getAbbreviatedLink(src.uri)}
                    </a>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {isLoading && (
          <div className="flex justify-start px-4">
            <div className="bg-white px-6 py-4 rounded-full flex items-center space-x-3 border border-gray-100 shadow-xl ring-4 ring-[#cc0033]/5">
              <div className="flex space-x-1.5">
                <div className="w-2 h-2 bg-[#cc0033] rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-[#cc0033] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-[#cc0033] rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
              <span className="text-[10px] font-black text-[#cc0033] uppercase tracking-widest italic">Scanning Knowledge Hub...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="p-10 bg-white border-t border-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="relative flex items-center bg-gray-50 rounded-[2rem] p-2 shadow-inner border border-gray-200 focus-within:ring-2 ring-[#cc0033]/10 transition-all">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={`Search your library about ${dept}...`}
              className="flex-1 bg-transparent border-none px-8 py-5 text-sm outline-none font-medium placeholder:text-gray-400"
            />
            <button
              onClick={handleSend}
              disabled={isLoading || !input.trim()}
              className="bg-[#cc0033] text-white p-5 rounded-3xl hover:bg-black transition-all disabled:opacity-10 shadow-lg active:scale-95"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 12h14M12 5l7 7-7 7" /></svg>
            </button>
          </div>
        </div>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="application/pdf, application/json" 
        className="hidden" 
      />
    </div>
  );
};

export default ChatInterface;