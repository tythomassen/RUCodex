
import React, { useState } from 'react';
import { Department, AcademicPlan, KnowledgeSource, Course, SemesterPlan } from '../types';
import { generatePlan } from '../services/geminiService';

interface AcademicPlannerProps {
  currentDept: Department;
  library: KnowledgeSource[];
}

interface DraggedItem {
  semesterIndex: number;
  courseIndex: number;
}

const abbreviateName = (name: string): string => {
  const mapping: Record<string, string> = {
    'Principles of Electrical Engineering': 'PEE',
    'Principles of EE': 'PEE',
    'Digital Logic Design': 'DLD',
    'Programming Methodology': 'PM',
    'General Psychology': 'Gen Psych',
    'Introduction to': 'Intro',
    'Computer Architecture': 'Comp Arch',
    'Software Engineering': 'Soft Eng',
    'Linear Systems and Signals': 'LSS',
    'Discrete Mathematics': 'Discrete Math',
    'Differential Equations': 'DiffEq',
    'Multivariable Calculus': 'Multi Calc',
    'Humanities/Social Science': 'H/SS',
    'Technical Elective': 'Tech Elect',
    'General Chemistry': 'Gen Chem',
    'Engineering Mechanics: Statics': 'Statics',
    'Analytical Physics': 'Physics',
    'Digital Electronics': 'Digi Elec',
    'Electronic Devices': 'Elec Devices',
    'Digital System Design': 'DSD',
    'Intro to Computer Systems': 'Comp Sys',
  };

  let abbreviated = name;
  for (const [full, abbr] of Object.entries(mapping)) {
    const regex = new RegExp(full, 'gi');
    abbreviated = abbreviated.replace(regex, abbr);
  }
  
  return abbreviated.trim();
};

const AcademicPlanner: React.FC<AcademicPlannerProps> = ({ currentDept, library }) => {
  const [option, setOption] = useState<string>('General Path');
  const [completedCourses, setCompletedCourses] = useState<string>('');
  const [dnText, setDnText] = useState<string>('');
  const [years, setYears] = useState<number>(4);
  const [preferences, setPreferences] = useState<string>('');
  const [plan, setPlan] = useState<AcademicPlan | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [draggedItem, setDraggedItem] = useState<DraggedItem | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const handleGenerate = async () => {
    setIsLoading(true);
    try {
      const courses = completedCourses.split(',').map(c => c.trim()).filter(c => c);
      const generated = await generatePlan(currentDept, option, courses, years, preferences, library, dnText);
      setPlan(generated);
    } catch (error) {
      alert("Plan synthesis failed.");
    } finally {
      setIsLoading(false);
    }
  };

  const onDragStart = (semesterIndex: number, courseIndex: number) => {
    setDraggedItem({ semesterIndex, courseIndex });
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const onDrop = (targetSemesterIndex: number) => {
    if (!draggedItem || !plan) return;

    const newPlan = { ...plan };
    const sourceSemester = newPlan.semesters[draggedItem.semesterIndex];
    const targetSemester = newPlan.semesters[targetSemesterIndex];

    const [movedCourse] = sourceSemester.courses.splice(draggedItem.courseIndex, 1);
    targetSemester.courses.push(movedCourse);

    sourceSemester.totalCredits = sourceSemester.courses.reduce((sum, c) => sum + c.credits, 0);
    targetSemester.totalCredits = targetSemester.courses.reduce((sum, c) => sum + c.credits, 0);

    setPlan(newPlan);
    setDraggedItem(null);
  };

  const deleteCourse = (semesterIndex: number, courseIndex: number) => {
    if (!plan) return;
    const newPlan = { ...plan };
    const semester = newPlan.semesters[semesterIndex];
    semester.courses.splice(courseIndex, 1);
    semester.totalCredits = semester.courses.reduce((sum, c) => sum + c.credits, 0);
    setPlan(newPlan);
  };

  const getAlertStyle = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-50 border-red-200 text-red-700';
      case 'medium': return 'bg-orange-50 border-orange-200 text-orange-700';
      default: return 'bg-blue-50 border-blue-200 text-blue-700';
    }
  };

  const CourseRow = ({ 
    course, 
    isElective, 
    onDragStart,
    onDelete
  }: { 
    course: Course, 
    isElective: boolean,
    onDragStart: () => void,
    onDelete: () => void
  }) => {
    const [selectedCode, setSelectedCode] = useState(course.code);
    
    const statusColors = {
      completed: 'bg-green-100 text-green-800 border-green-200',
      'in-progress': 'bg-blue-100 text-blue-800 border-blue-200',
      planned: 'bg-gray-100 text-gray-800 border-gray-200'
    };

    const displayName = abbreviateName(course.name);

    return (
      <div 
        draggable
        onDragStart={onDragStart}
        className={`px-2 py-1.5 border-b border-gray-100 flex items-center justify-between text-[10px] group hover:bg-gray-50 transition-colors cursor-move active:opacity-50 active:scale-95 relative`}
        title={course.name}
      >
        <div className="flex-1 min-w-0 pr-2">
          <div className="flex items-center gap-1 mb-0.5">
            <span className={`px-1 py-0 rounded-[2px] text-[7px] font-black uppercase border ${statusColors[course.status || 'planned']}`}>
              {course.status === 'completed' ? (course.grade || 'C') : course.status === 'in-progress' ? 'IP' : 'PL'}
            </span>
            {isElective && <span className="text-[7px] font-black text-[#cc0033] bg-red-50 px-1 py-0 rounded uppercase">EL</span>}
          </div>
          
          {course.options && course.options.length > 0 ? (
            <select 
              className="w-full font-bold bg-white border border-gray-200 rounded p-0 text-[9px] outline-none focus:border-[#cc0033] cursor-default"
              value={selectedCode}
              onChange={(e) => setSelectedCode(e.target.value)}
              onClick={(e) => e.stopPropagation()}
            >
              <option value={course.code}>{course.code}: {displayName}</option>
              {course.options.map(opt => (
                <option key={opt.code} value={opt.code} title={opt.name}>{opt.code}: {abbreviateName(opt.name)}</option>
              ))}
            </select>
          ) : (
            <p className="font-bold truncate text-gray-900 pointer-events-none">{course.code}: {displayName}</p>
          )}
        </div>
        
        <div className="flex items-center gap-2 shrink-0">
          <p className="text-gray-400 font-black text-[9px] group-hover:hidden">{course.credits}c</p>
          <button 
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
            className="hidden group-hover:flex text-red-500 hover:text-red-700 p-0.5 transition-colors"
            title="Delete Course"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-row h-full overflow-hidden relative">
      <div className={`transition-all duration-300 ease-in-out bg-gray-50 border-r border-gray-100 flex flex-col ${isSidebarOpen ? 'w-80' : 'w-0 overflow-hidden'}`}>
        <div className="p-6 overflow-y-auto flex flex-col h-full">
          <div className="mb-6 flex justify-between items-center">
            <h2 className="text-[10px] font-black text-gray-900 uppercase tracking-[0.3em] border-l-4 border-[#cc0033] pl-3">Parameters</h2>
            <button onClick={() => setIsSidebarOpen(false)} className="text-gray-400 hover:text-black">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            </button>
          </div>
          
          <div className="space-y-4 flex-1">
            <div>
              <label className="block text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Major Option</label>
              <input
                type="text"
                value={option}
                onChange={(e) => setOption(e.target.value)}
                className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-[#cc0033]/10 outline-none font-medium shadow-sm"
                placeholder="e.g. Computer Engineering"
              />
            </div>

            <div>
              <label className="block text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Degree Navigator (Paste)</label>
              <textarea
                value={dnText}
                onChange={(e) => setDnText(e.target.value)}
                placeholder="Paste from DN..."
                className="w-full h-32 bg-white border border-gray-200 rounded-lg px-3 py-2 text-[9px] focus:ring-2 focus:ring-[#cc0033]/10 outline-none resize-none font-mono leading-tight shadow-sm"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Manual Done</label>
                <input
                  type="text"
                  value={completedCourses}
                  onChange={(e) => setCompletedCourses(e.target.value)}
                  placeholder="Codes..."
                  className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-[10px] font-mono shadow-sm"
                />
              </div>
              <div>
                <label className="block text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Years</label>
                <select 
                  value={years} 
                  onChange={(e) => setYears(Number(e.target.value))}
                  className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-[10px] font-bold shadow-sm"
                >
                  {[1,2,3,4,5].map(y => <option key={y} value={y}>{y}y</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Preferences</label>
              <textarea
                value={preferences}
                onChange={(e) => setPreferences(e.target.value)}
                placeholder="Light fall, focus software..."
                className="w-full h-16 bg-white border border-gray-200 rounded-lg px-3 py-2 text-[10px] focus:ring-2 focus:ring-[#cc0033]/10 outline-none resize-none shadow-sm"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full bg-black text-white font-black text-[9px] uppercase tracking-[0.2em] py-4 rounded-xl shadow-lg hover:bg-[#cc0033] transition-all disabled:opacity-30 active:scale-95"
            >
              {isLoading ? "Synthesizing..." : "Generate Plan"}
            </button>
          </div>
        </div>
      </div>

      {!isSidebarOpen && (
        <button 
          onClick={() => setIsSidebarOpen(true)}
          className="absolute left-4 top-4 z-10 bg-white border border-gray-200 p-2 rounded-lg shadow-md hover:bg-gray-50 transition-all"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
        </button>
      )}

      <div className="flex-1 p-6 overflow-y-auto bg-white flex flex-col min-w-0">
        {!plan && !isLoading && (
          <div className="h-full flex flex-col items-center justify-center text-gray-200">
             <div className="w-12 h-12 border-4 border-dashed border-gray-100 rounded-full mb-4 animate-spin duration-[15s]"></div>
             <p className="text-[9px] font-black uppercase tracking-[0.4em] text-center max-w-xs">Awaiting data for synthesis</p>
          </div>
        )}

        {isLoading && (
          <div className="h-full flex flex-col items-center justify-center">
             <div className="w-10 h-10 border-4 border-[#cc0033] border-t-transparent rounded-full mb-4 animate-spin"></div>
             <p className="text-[9px] font-black text-[#cc0033] uppercase tracking-[0.3em] animate-pulse">Solving Prereqs...</p>
          </div>
        )}

        {plan && (
          <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
            <div className="flex justify-between items-center border-b pb-4">
              <div>
                <h3 className="text-xl font-black text-gray-900 tracking-tighter uppercase italic">{plan.majorOption}</h3>
                <p className="text-[8px] font-black text-gray-400 uppercase tracking-[0.2em]">{currentDept}</p>
              </div>
              <div className="flex gap-2">
                <button className="bg-gray-100 hover:bg-gray-200 text-gray-600 px-3 py-1.5 rounded-md text-[8px] font-black uppercase tracking-widest">CSV</button>
                <button className="bg-[#cc0033] hover:bg-black text-white px-3 py-1.5 rounded-md text-[8px] font-black uppercase tracking-widest shadow-sm">Export</button>
              </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 bg-gray-50 p-2 rounded-xl border border-gray-200 overflow-x-auto min-h-[500px]">
              {plan.semesters.map((sem, sIdx) => (
                <div 
                  key={sIdx} 
                  onDragOver={onDragOver}
                  onDrop={() => onDrop(sIdx)}
                  className={`bg-white border border-gray-200 rounded-lg shadow-sm flex flex-col transition-all duration-200 ${
                    draggedItem !== null ? 'ring-2 ring-dashed ring-blue-300' : ''
                  }`}
                >
                  <div className="bg-gray-900 text-white px-2 py-1.5 flex justify-between items-center rounded-t-lg">
                    <h4 className="font-black text-[9px] uppercase tracking-widest truncate">{sem.semesterName}</h4>
                    <span className="text-[8px] font-black opacity-50">{sem.totalCredits}cr</span>
                  </div>
                  <div className="flex-1 min-h-[100px]">
                    {sem.courses.map((course, cIdx) => (
                      <CourseRow 
                        key={`${sIdx}-${cIdx}`} 
                        course={course} 
                        isElective={!!course.options && course.options.length > 0} 
                        onDragStart={() => onDragStart(sIdx, cIdx)}
                        onDelete={() => deleteCourse(sIdx, cIdx)}
                      />
                    ))}
                    {sem.courses.length === 0 && (
                      <div className="p-4 flex items-center justify-center opacity-10 italic text-[8px] font-black uppercase">Empty</div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4">
              <div className="lg:col-span-1">
                <h4 className="text-[9px] font-black text-gray-400 uppercase tracking-widest pl-2 border-l-2 border-red-500 mb-2">Conflicts</h4>
                <div className="max-h-[200px] overflow-y-auto space-y-2 pr-2">
                  {plan.validationAlerts.length === 0 ? (
                    <div className="p-3 rounded-lg bg-green-50 border border-green-100 flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center text-white shrink-0">
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7"/></svg>
                      </div>
                      <p className="text-[9px] font-black text-green-700 uppercase">Valid</p>
                    </div>
                  ) : (
                    plan.validationAlerts.map((alert, idx) => (
                      <div key={idx} className={`p-2 rounded-lg border-l-2 ${getAlertStyle(alert.severity)}`}>
                        <span className="text-[8px] font-black uppercase block">[{alert.courseCode}]</span>
                        <p className="text-[10px] font-medium leading-tight">{alert.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="lg:col-span-2">
                <h4 className="text-[9px] font-black text-gray-400 uppercase tracking-widest pl-2 border-l-2 border-[#cc0033] mb-2">Strategy</h4>
                <div className="bg-black text-white p-4 rounded-2xl shadow-lg h-[150px] overflow-y-auto">
                   <div className="text-[10px] leading-relaxed text-gray-300 space-y-2 font-medium">
                     {plan.rationale.split('\n').map((line, li) => <p key={li}>{line}</p>)}
                   </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AcademicPlanner;
